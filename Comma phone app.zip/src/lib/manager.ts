export type Config = { url: string; token: string; mock: boolean };
export type Ack = { ok: boolean; status: number; body: unknown; at: string; action: string };
export type Route = {
  id: string; label: string; destination: string; stops: string[];
  coordinates: [number, number][]; origin: string;
  distance_meters: number; duration_seconds: number; source: string;
};

const KEY = "manager-config";
export const defaultConfig: Config = { url: "http://192.168.1.100:8765", token: "c4-test-token-2026", mock: true };
export function loadConfig(): Config {
  try { return { ...defaultConfig, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; } catch { return defaultConfig; }
}
export function saveConfig(c: Config) { localStorage.setItem(KEY, JSON.stringify(c)); }

// ---- mock state ----
const mock = {
  settings: {
    OpenpilotEnabledToggle: true, ExperimentalMode: false, IsMetric: true, IsLdwEnabled: true,
    DisengageOnAccelerator: false, RecordFront: false, EnableMads: true, MadsSteeringMode: "remain_active",
    DynamicExperimentalControl: false, NNFF: false, TorqueParamsOverrideEnabled: false,
    AutoLaneChangeTimer: 2, LongitudinalPersonality: 1, SpeedLimitMode: 1, CustomAccIncrementsEnabled: false,
    ShowDebugInfo: false, QuietMode: false,
  } as Record<string, unknown>,
  route: null as Route | null,
  files: [] as string[],
};

function mockHandle(method: string, path: string, body?: unknown): { status: number; body: unknown } {
  if (path === "/api/status") return { status: 200, body: { manager: "online", agent: "online", mode: "mock", navigation: { active: !!mock.route, route_id: mock.route?.id ?? null }, staged_files: mock.files } };
  if (path === "/api/settings" && method === "GET") return { status: 200, body: mock.settings };
  if (path === "/api/settings" && method === "POST") { Object.assign(mock.settings, body as object); return { status: 200, body: { ok: true, applied: body } }; }
  if (path === "/api/navigation/route") {
    if (method === "GET") return { status: 200, body: mock.route };
    if (method === "POST") { mock.route = body as Route; return { status: 200, body: { ok: true, id: mock.route.id } }; }
    if (method === "DELETE") { mock.route = null; return { status: 200, body: { ok: true, cleared: true } }; }
  }
  if (path === "/api/navigation/status") return { status: 200, body: { active: !!mock.route, destination: mock.route?.destination ?? null } };
  if (path === "/api/files/upload") { const n = (body as FormData).get("file") as File; mock.files.push(n.name); return { status: 200, body: { ok: true, staged: n.name, size: n.size, executed: false } }; }
  return { status: 404, body: { error: "not found" } };
}

export async function call(cfg: Config, method: string, path: string, body?: unknown): Promise<Ack> {
  const at = new Date().toLocaleTimeString();
  const action = `${method} ${path}`;
  if (cfg.mock) {
    await new Promise((r) => setTimeout(r, 200));
    const r = mockHandle(method, path, body);
    return { ok: r.status < 300, status: r.status, body: r.body, at, action };
  }
  const isForm = body instanceof FormData;
  const headers: Record<string, string> = { Authorization: `Bearer ${cfg.token}`, "X-Device-Token": cfg.token };
  if (body !== undefined && !isForm) headers["Content-Type"] = "application/json";
  try {
    const res = await fetch(cfg.url.replace(/\/$/, "") + path, {
      method, headers, body: body === undefined ? null : isForm ? (body as FormData) : JSON.stringify(body),
    });
    const text = await res.text();
    let parsed: unknown = text;
    try { parsed = JSON.parse(text); } catch { /* text */ }
    return { ok: res.ok, status: res.status, body: parsed, at, action };
  } catch (e) {
    return { ok: false, status: 0, body: `Network error: ${(e as Error).message}. Check IP, same Wi-Fi, and that the app is opened over http://`, at, action };
  }
}
