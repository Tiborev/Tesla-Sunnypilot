import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { call, defaultConfig, loadConfig, saveConfig, type Ack, type Config, type Route as NavRoute } from "@/lib/manager";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Comma — Manager Control" },
      { name: "description", content: "Control Tesla-Sunnypilot settings, navigation and file staging from your phone." },
      { property: "og:title", content: "Comma" },
      { property: "og:description", content: "Phone control app for the Comma Manager API." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: App,
});

type Tab = "status" | "settings" | "nav" | "files" | "connect";
const card = "rounded-xl border border-border bg-card p-4";
const btn = "rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground active:opacity-80 disabled:opacity-50";
const btn2 = "rounded-lg border border-border px-4 py-2.5 text-sm font-medium text-foreground active:bg-accent";
const input = "w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground";

function App() {
  const [cfg, setCfg] = useState<Config>(defaultConfig);
  const [tab, setTab] = useState<Tab>("status");
  const [acks, setAcks] = useState<Ack[]>([]);
  useEffect(() => { setCfg(loadConfig()); document.documentElement.classList.add("dark"); }, []);
  const run = async (m: string, p: string, b?: unknown) => { const a = await call(cfg, m, p, b); setAcks((x) => [a, ...x].slice(0, 30)); return a; };
  const last = acks[0];

  return (
    <div className="dark min-h-screen bg-background pb-24 text-foreground">
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur">
        <div>
          <h1 className="text-lg font-bold tracking-tight">Comma</h1>
          <p className="text-xs text-muted-foreground">{cfg.mock ? "MOCK mode" : cfg.url}</p>
        </div>
        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${cfg.mock ? "bg-secondary text-secondary-foreground" : "bg-primary text-primary-foreground"}`}>{cfg.mock ? "MOCK" : "LIVE"}</span>
      </header>

      <main className="mx-auto max-w-xl space-y-4 p-4">
        {last && (
          <div className={`${card} ${last.ok ? "" : "border-destructive"}`}>
            <div className="flex justify-between text-xs"><span className="font-mono">{last.action}</span><span className={last.ok ? "text-primary" : "text-destructive"}>{last.ok ? "ACK" : "FAIL"} {last.status} · {last.at}</span></div>
          </div>
        )}
        {tab === "status" && <StatusTab run={run} acks={acks} />}
        {tab === "settings" && <SettingsTab run={run} />}
        {tab === "nav" && <NavTab run={run} />}
        {tab === "files" && <FilesTab run={run} />}
        {tab === "connect" && <ConnectTab cfg={cfg} onSave={(c) => { saveConfig(c); setCfg(c); }} run={run} />}
      </main>

      <nav className="fixed inset-x-0 bottom-0 grid grid-cols-5 border-t border-border bg-background">
        {([["status", "Status"], ["settings", "Settings"], ["nav", "Route"], ["files", "Files"], ["connect", "Connect"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`py-4 text-sm font-medium ${tab === k ? "text-primary border-t-2 border-primary" : "text-muted-foreground"}`}>{l}</button>
        ))}
      </nav>
    </div>
  );
}

type Run = (m: string, p: string, b?: unknown) => Promise<Ack>;
const Json = ({ v }: { v: unknown }) => <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-muted p-3 text-xs">{typeof v === "string" ? v : JSON.stringify(v, null, 2)}</pre>;

function StatusTab({ run, acks }: { run: Run; acks: Ack[] }) {
  const [s, setS] = useState<Ack | null>(null);
  const refresh = async () => setS(await run("GET", "/api/status"));
  useEffect(() => { refresh(); }, []);
  return (
    <>
      <div className={card}>
        <div className="mb-3 flex items-center justify-between"><h2 className="font-semibold">Manager status</h2><button className={btn2} onClick={refresh}>Refresh</button></div>
        {s && <Json v={s.body} />}
      </div>
      <div className={card}>
        <h2 className="mb-2 font-semibold">Acknowledgement log</h2>
        <ul className="space-y-1 text-xs">
          {acks.map((a, i) => <li key={i} className="flex justify-between gap-2 border-b border-border py-1.5"><span className="font-mono">{a.action}</span><span className={a.ok ? "text-primary" : "text-destructive"}>{a.status || "ERR"} {a.at}</span></li>)}
        </ul>
      </div>
    </>
  );
}

function SettingsTab({ run }: { run: Run }) {
  const [settings, setSettings] = useState<Record<string, unknown> | null>(null);
  const [err, setErr] = useState<unknown>(null);
  const [filter, setFilter] = useState("");
  const load = async () => { const a = await run("GET", "/api/settings"); if (a.ok && a.body && typeof a.body === "object") { setSettings(((a.body as any).settings ?? a.body) as Record<string, unknown>); setErr(null); } else setErr(a.body); };
  useEffect(() => { load(); }, []);
  const set = async (k: string, v: unknown) => { const a = await run("POST", "/api/settings", { [k]: v }); if (a.ok) setSettings((s) => ({ ...s, [k]: v })); };
  const setAll = async (v: boolean) => {
    if (!settings) return;
    const batch = Object.fromEntries(Object.entries(settings).filter(([, x]) => typeof x === "boolean").map(([k]) => [k, v]));
    const a = await run("POST", "/api/settings", batch); if (a.ok) setSettings((s) => ({ ...s, ...batch }));
  };
  const entries = Object.entries(settings ?? {}).filter(([k]) => k.toLowerCase().includes(filter.toLowerCase()));
  return (
    <div className="space-y-3">
      <div className="flex gap-2"><input className={input} placeholder="Search settings" value={filter} onChange={(e) => setFilter(e.target.value)} /><button className={btn2} onClick={load}>Reload</button></div>
      <div className="flex gap-2"><button className={btn2} onClick={() => setAll(true)}>All ON</button><button className={btn2} onClick={() => setAll(false)}>All OFF</button></div>
      {err != null && <Json v={err} />}
      {entries.map(([k, v]) => (
        <div key={k} className={`${card} flex items-center justify-between gap-3`}>
          <span className="break-all text-sm font-medium">{k}</span>
          {typeof v === "boolean" ? (
            <button onClick={() => set(k, !v)} aria-label={k} className={`relative h-8 w-14 shrink-0 rounded-full transition ${v ? "bg-primary" : "bg-muted"}`}>
              <span className={`absolute top-1 h-6 w-6 rounded-full bg-background transition ${v ? "left-7" : "left-1"}`} />
            </button>
          ) : (
            <input className={`${input} w-32`} defaultValue={String(v ?? "")} onBlur={(e) => { const raw = e.target.value; const val = typeof v === "number" ? Number(raw) : raw; if (val !== v) set(k, val); }} />
          )}
        </div>
      ))}
    </div>
  );
}

function NavTab({ run }: { run: Run }) {
  const [f, setF] = useState({ label: "", origin: "", destination: "", stops: "", coords: "", distance: "0", duration: "0" });
  const [out, setOut] = useState<unknown>(null);
  const u = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const send = async () => {
    let coordinates: [number, number][] = [];
    try { coordinates = f.coords.trim() ? JSON.parse(f.coords) : []; } catch { setOut("Coordinates must be JSON, e.g. [[47.49,19.04],[47.50,19.05]]"); return; }
    const route: NavRoute = { id: crypto.randomUUID(), label: f.label, destination: f.destination, origin: f.origin, stops: f.stops.split("\n").map((s) => s.trim()).filter(Boolean), coordinates, distance_meters: Number(f.distance), duration_seconds: Number(f.duration), source: "phone-app" };
    setOut((await run("POST", "/api/navigation/route", route)).body);
  };
  const onGpx = async (file: File) => {
    const txt = await file.text();
    const pts = [...txt.matchAll(/lat="([-\d.]+)"\s+lon="([-\d.]+)"/g)].map((m) => [Number(m[1]), Number(m[2])]);
    setF({ ...f, coords: JSON.stringify(pts) });
  };
  return (
    <div className="space-y-3">
      <div className={`${card} space-y-2`}>
        <h2 className="font-semibold">Send route</h2>
        <input className={input} placeholder="Label" value={f.label} onChange={u("label")} />
        <input className={input} placeholder="Origin" value={f.origin} onChange={u("origin")} />
        <input className={input} placeholder="Destination" value={f.destination} onChange={u("destination")} />
        <textarea className={input} rows={2} placeholder="Stops (one per line)" value={f.stops} onChange={u("stops")} />
        <textarea className={`${input} font-mono`} rows={3} placeholder="Coordinates JSON [[lat,lon],...]" value={f.coords} onChange={u("coords")} />
        <label className="block text-xs text-muted-foreground">Or load geometry from GPX file
          <input type="file" accept=".gpx,application/gpx+xml" className="mt-1 block w-full text-sm" onChange={(e) => e.target.files?.[0] && onGpx(e.target.files[0])} />
        </label>
        <div className="flex gap-2"><input className={input} inputMode="numeric" placeholder="Distance m" value={f.distance} onChange={u("distance")} /><input className={input} inputMode="numeric" placeholder="Duration s" value={f.duration} onChange={u("duration")} /></div>
        <button className={`${btn} w-full`} onClick={send}>Send route</button>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <button className={btn2} onClick={async () => setOut((await run("GET", "/api/navigation/route")).body)}>Current</button>
        <button className={btn2} onClick={async () => setOut((await run("GET", "/api/navigation/status")).body)}>Status</button>
        <button className={btn2} onClick={async () => setOut((await run("DELETE", "/api/navigation/route")).body)}>Clear</button>
      </div>
      {out != null && <Json v={out} />}
    </div>
  );
}

function FilesTab({ run }: { run: Run }) {
  const [file, setFile] = useState<File | null>(null);
  const [path, setPath] = useState("/api/files/upload");
  const [out, setOut] = useState<unknown>(null);
  const upload = async () => { if (!file) return; const fd = new FormData(); fd.append("file", file); fd.append("filename", file.name); setOut((await run("POST", path, fd)).body); };
  return (
    <div className={`${card} space-y-3`}>
      <h2 className="font-semibold">Stage file</h2>
      <p className="text-xs text-muted-foreground">Files are staged on the device only — never executed automatically.</p>
      <input type="file" className="block w-full text-sm" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
      <label className="block text-xs text-muted-foreground">Upload endpoint<input className={`${input} mt-1 font-mono`} value={path} onChange={(e) => setPath(e.target.value)} /></label>
      <button className={`${btn} w-full`} disabled={!file} onClick={upload}>Upload {file ? `(${(file.size / 1024).toFixed(1)} KB)` : ""}</button>
      {out != null && <Json v={out} />}
    </div>
  );
}

function ConnectTab({ cfg, onSave, run }: { cfg: Config; onSave: (c: Config) => void; run: Run }) {
  const [c, setC] = useState(cfg);
  useEffect(() => setC(cfg), [cfg]);
  return (
    <div className={`${card} space-y-3`}>
      <h2 className="font-semibold">Connection</h2>
      <label className="block text-sm">Manager URL<input className={`${input} mt-1 font-mono`} value={c.url} onChange={(e) => setC({ ...c, url: e.target.value })} placeholder="http://192.168.x.x:8765" /></label>
      <label className="block text-sm">Device token<input className={`${input} mt-1 font-mono`} value={c.token} onChange={(e) => setC({ ...c, token: e.target.value })} /></label>
      <label className="flex items-center justify-between text-sm">Mock mode (test outside the car)
        <input type="checkbox" className="h-5 w-5" checked={c.mock} onChange={(e) => setC({ ...c, mock: e.target.checked })} />
      </label>
      <div className="flex gap-2"><button className={`${btn} flex-1`} onClick={() => onSave(c)}>Save</button><button className={`${btn2} flex-1`} onClick={() => run("GET", "/api/status")}>Test</button></div>
      <p className="text-xs text-muted-foreground">Phone and Manager must be on the same Wi-Fi/hotspot. Browsers block plain http:// calls from an https:// page — for live mode, open this app over http or allow insecure content for this site in Chrome/Samsung Internet site settings.</p>
    </div>
  );
}
